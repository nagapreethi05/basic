import { Link } from 'react-router-dom';
import React, { useContext, useEffect } from 'react'
import { movie } from './movie';
import OneMovie from './OneMovie';
import Searching from './Search';
import UserContext from './UserContext';
import { movieManager } from './movieManager'

interface movielistprops {
    list: movie[]

}
let bmObj = new movieManager
const MovieList: React.FC<movielistprops> = (props) => {
    const { moviesArray, dispatch } = useContext(UserContext);
    const initialState = useContext(UserContext)

    useEffect(() => {
        bmObj.getAllMovies(dispatch);
    }, [])
   
    let movie = initialState.moviesArray.books.map((movie: any, index: any) => {
        return (
            <div>
                <Link to={`/${movie._id}`}>
                    <OneMovie movie={movie}></OneMovie>

                </Link>
            </div>
        )

    })
    return (
        <>
            <div>
                <Searching list={props.list}></Searching>
            </div>
            <div>
                {movie}
            </div>
        </>
    )
}

export default MovieList

