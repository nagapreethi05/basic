import express from 'express';
import cors from 'cors';
import  moviesRouter  from './Routers/Movies-routers';
import  usersRouter  from './Routers/Users-routers'
import dotenv from 'dotenv'
import connectionToDB from './connection-to-db';
dotenv.config();
const startServer = () => {
    const app = express();
    app.use(express.json());
    app.use(cors());

    connectionToDB()
        .then(() => {
            console.log("connected to db");
            app.listen(process.env.PORT, () => {
                console.log(`server running at http://localhost:${process.env.PORT}`);
            });
            app.use('/api/movies', moviesRouter);
            
            app.use('/api/users', usersRouter)
            app.use('/', (req: any, res: any) => {
                res.status(200).json('connected to test')
            })
        })
        .catch((err: any) => {
            console.log(err.message);
        })
}

startServer();