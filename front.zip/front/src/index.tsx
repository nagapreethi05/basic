import React, { useState, useEffect, useContext } from 'react';
import ReactDOM from 'react-dom';
import './styles.css';

import reportWebVitals from './reportWebVitals';
import { movie } from './components/movie';
import MovieList from './components/MovieList'
import { Redirect } from 'react-router-dom';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
// import Login from './components/login'
import Login from './components/Login1'
import Register from './components/register'
import ContactUs from './components/contactus'
import Details from './components/Details'
import { Navbar, Nav } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import UserContext, { UserProvider } from './components/UserContext'


const MovieApp = () => {
  const [movies, setMovie] = useState<movie[]>([])
  const [window, setWindow] = useState<boolean>(false)
  const [deletewin, setDeleteWindow] = useState(false)
  const [user, setUser] = useState(false)
  const [userfailed, setUserFailed] = useState("")
  
  useEffect(() => {

    if (localStorage.getItem("login")) {
      setUser(true);
    }

  }, [window, deletewin]);

  const authentication = async (username: string, password: string) => {
    let auth = await fetch(`http://localhost:9000/api/users/login/`, {
      method: "POST",
      body: JSON.stringify({ username: username, password: password }),
      headers: { "Content-Type": "application/json" }
    });
    let valid = await auth.json();
    console.log(valid);
    if (valid == "Invalid") {
      setUser(false);
      setUserFailed("error");
    } else {
      localStorage.setItem("login", valid)
      setUser(true);
      setUserFailed("pass");
    }
  }
  const handleNewUser = async (newUser: any) => {
    console.log("reg")
    await fetch("http://localhost:9000/api/users/registration", {
      method: "POST",
      body: JSON.stringify(newUser),
      headers: { "Content-Type": "application/json" }
    })
    setWindow(true);
  }
  
  const logout = () => {
    setUser(false);
    localStorage.clear();
  }
  useEffect(() => {
    setWindow(false);
  }, [window])

  useEffect(() => {
    setDeleteWindow(false);
  }, [deletewin])

  return (
    <UserProvider>
      <div>
        <div>
          <h1 className="bookHeader">OMDB Movies</h1>
          <hr></hr>
        </div>

        <div >
          <Router>
            <Navbar bg="success" variant="dark">
              <Nav className="mr-auto">
                <Nav.Link as={Link} to="/">Home</Nav.Link>
                {/* {user ? <Nav.Link as={Link} to="/addbooks">Add Book</Nav.Link> : null} */}
                {user ? null : <Nav.Link as={Link} to="/login">Login</Nav.Link>}
                {user ? null : <Nav.Link as={Link} to="/register">Register</Nav.Link>}
                <Nav.Link as={Link} to="/contactus">ContactUs</Nav.Link>
                {user ? <Nav.Link as={Link} to="/" onClick={() => logout()}>LogOut</Nav.Link> : null}
              </Nav>
            </Navbar>
            <Switch>
              <Route exact path="/">
                <MovieList list={movies}></MovieList>
              </Route>
              {/* <Route exact path="/addbooks">
                <AddBook ></AddBook>
                {window ? <Redirect to='/'></Redirect> : null}
              </Route> */}
              <Route exact path="/login">
                <Login valid={userfailed} handlelogin={(username: string, password: string) => authentication(username, password)}></Login>
                {window ? <Redirect to='/'></Redirect> : null}
              </Route>
              <Route exact path="/register">
                <Register handleregistration={(newUser: any) => { handleNewUser(newUser) }}></Register>
                {window ? <Redirect to='/login'></Redirect> : null}
              </Route>
              <Route exact path="/contactus">
                <ContactUs></ContactUs>
              </Route>
              <Route exact path="/:_id">
                <Details userCheck={user}  ></Details>
                {deletewin ? <Redirect to='/'></Redirect> : null}
              </Route>
            </Switch>
          </Router>
        </div>
      </div>
    </UserProvider>
  )
}
ReactDOM.render(
  <React.StrictMode>

    <MovieApp></MovieApp>

  </React.StrictMode>,
  document.getElementById('root')
);
reportWebVitals();
