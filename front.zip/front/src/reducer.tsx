import { movie } from './components/movie';
type state = {
    books: movie[],
    users: any[],
    user: boolean
}
type Action =
    
    | { type: "LIST", books: movie[] }
    | { type: "LOGOUT" }
    | { type: "SEARCH", data: string, category: string }
    | { type: "LOGIN", user: { username: string, password: string } }
    | { type: "LOGINWITHOTP", withOtp: { username: string, password: string, otp: string } }
const reducer = (state: state, action: Action): any => {
    switch (action.type) {
        case "LIST":
            state.books = []
            return {
                ...state,
                books: [...state.books.concat(action.books)]
            }
       
        case "LOGIN":
            return {
                ...state,
                user: true
            }
        case "LOGOUT":
            return {
                ...state,
                user: false
            }
        
        case "LOGINWITHOTP":
        default:
            return state
    }
}
export default reducer