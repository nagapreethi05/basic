import express from 'express';
import mongoose from 'mongoose';
import User from '../Model/users-schema';
import jwt from 'jsonwebtoken'
export const usersRouter = express.Router()

export const userlogin=async (req: any, res: any) => {
    const username = req.body.username;
    const password = req.body.password;

    if (username && password) {
        try {
            const user = await User.findOne({ username: username });
            if (user) {
                const pass = await User.findOne({ password: password });
                if (pass) {

                    otpGenerating(req, res);

                    res.status(200).json("logged-in");
                } else {
                    res.status(404).json("password is wrong");
                }
            } else {
                res.status(401).json("Invalid");
            }
        } catch (err: any) {

            console.log(err);
        }
    }
};
function otpGenerating(req: any, res: any) {
    var TWILIO_TOKEN = "bd645908a29e3ab562297e82f09f1070";
    var TWILIO_ACCOUNT_SID = "ACd38bc180240e10e20c987600fe37e9f6";
    var client = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_TOKEN);
    let otp = "";
    for (let i = 1; i <= 6; i++) {
        otp += Math.floor((Math.random() * 10));
        console.log(otp);
    }
    client.messages.create({
        from: " +12064832626",
        to: "+918500253867",
        body: `OTP:${otp} is your otp for book management App,please enter otp with in 2mins`,
    })
        .then(async (message: any) => {
            const time = 2 * 60 * 1000;
            console.log(time);
            const expires = Date.now() + time;
            console.log(expires);
            await User.updateOne({ "username": req.body.username }, { $set: { "otp": otp, "time": expires } })

        }).catch((err: any) => {
            console.log(err)
        })
}
export const otpverify= async (req: any, res: any) => {
    const username = req.body.username;
    const password = req.body.password;
    const otp = req.body.otp;
    
    try {
        let user = await User.findOne({ otp: otp });
        console.log(user);
        if (user) {
            console.log(user.username, user.password);
            console.log(username, password);
            if (user.username === username && user.password === password) {
                if (Date.now() >= user.time) {
                    res.status(401).json("otp expired")
                } else {
                    const codeUser = { username: username, password: password }
                    const token = jwt.sign(codeUser, "NagaPreethi");
                    res.status(200).json(token);
                }
            } else {
                res.status(401).json("something wrong")
            }
        } else {
            res.status(403).json("otp wrong")
        }
    } catch (err) {
        res.send(404).json("error occured", err.message)
    }
}

export const getuser=async (req: any, res: any) => {
console.log("connected to test")
    try {
        const user = await User.find({});
        res.json(user)
    } catch (err) {
        res.send('Error ' + err)
    }

}
export const registration=async (req: any, res: any) => {
    const newUser = new User({
        username: req.body.username,
        password: req.body.password,
        phonenumber: req.body.phonenumber,
        address: req.body.address
    })
    try {
        const u1 = await newUser.save()
        res.json(u1)
    } catch (err) {
        res.status(401).json("error")
    }
}
export function authenticate(req: any, res: any, next: any) {
    const header = req.header('Authorization');
    const token = header && header.split(' ')[1];
    console.log(token)
    if (token == null) {
        return res.sendStatus(401);
    }
    jwt.verify(token, "NagaPreethi", (err: any, user: any) => {
        if (err) {
            return res.sendStatus(403);
        }
        req.user = User;
        next();
    })
}