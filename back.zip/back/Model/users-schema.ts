const mongoosee = require('mongoose')
const userSchema = new mongoosee.Schema({

    username: {
        type: String,
        required: true,
        unique:true,
        lowercase:true
    },
    password: {
        type: String,
        required:false,
        minLength:6

    },
    phonenumber: {
        type: String,
        required:false
    },
    address: {
        type: String,
        required:false
    },
    otp:{
        type:String,
        required:false
    },
    time:{
        type:String,
        required:false
    }   
},

    { collection: "Authentication" }
)
export = mongoosee.model('User', userSchema)