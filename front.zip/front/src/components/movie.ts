export class movie{
    Poster:string;
    Title:string;
    Year:string;
    imdbID:string;
    Director:string;
    Rated:string;
    Released:string;
    Genre:string
constructor(Poster:string,Title:string,Year:string,
    imdbID:string,Director:string,Rated:string,Released:string,
    Genre:string,
    ){
    this.Poster=Poster;
    this.Title=Title;
    this.Year=Year;
    this.imdbID=imdbID;
    this.Director=Director;
    this.Rated=Rated;
    this.Released=Released;
    this.Genre=Genre;
    
}
}