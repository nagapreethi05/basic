"use strict";
var mongoosee = require('mongoose');
var registrationSchema = new mongoosee.Schema({
    email: {
        type: String,
        required: true,
    },
    password: {
        type: String,
    },
    confirmpassword: {
        type: String,
    }
}, { collection: "registration" });
module.exports = mongoosee.model('registration', registrationSchema);
