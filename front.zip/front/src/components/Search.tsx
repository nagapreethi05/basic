import React, { useState, useEffect } from 'react'
import { movie } from './movie';
import OneMovie from './OneMovie';
import { Link } from 'react-router-dom';
interface Props {
    list: movie[]
}

const Searching: React.FC<Props> = (props) => {
    const [search, setSearch] = useState<string>("");
    const [searchArray, setSearchArray] = useState<movie[]>([])
    const [select, setSelect] = useState("");
    const [searchButton, setSearchButton] = useState("");
    const [price, setPrice] = useState(false);
    const [minPrice, setMinPrice] = useState("");
    const [maxPrice, setMaxPrice] = useState("");
    const [searchPrice, setSearchPrice] = useState("");

    useEffect(() => {
        if (select == "price") {
            setPrice(true)
        }
        else {
            setPrice(false)
        }
    }, [select])
    const handleSelect = (e: any) => {
        console.log(e.target.value)
        setSelect(e.target.value);
    }
    const handleSearch = (e: any) => {
        console.log(e.target.value)
        setSearch(e.target.value);
    }

    const handleSearchButton = () => {
        setSearchArray([]);
       
        if (search && search != ""&&search.startsWith("tt")) {
            fetch(`http://localhost:9000/api/movies/${search}`)
                .then(response => {
                    if (response.ok) {

                        return response.json()
                    }
                    throw response;
                })
                .then(data => {
                    setSearchArray(searchArray => searchArray.concat(data));
                })
                .catch(err => {
                    console.log(err);
                })
        }else{
           
                fetch(`http://localhost:9000/api/movies/search/${search}`)
                    .then(response => {
                        if (response.ok) {
    
                            return response.json()
                        }
                        throw response;
                    })
                    .then(data => {
                        setSearchArray(searchArray => searchArray.concat(data));
                    })
                    .catch(err => {
                        console.log(err);
                    })
            
        }

    }
    // const handleChangeMinPrice = (e: any) => {
    //     console.log(e.target.value)
    //     setMinPrice(e.target.value);
    // }
    // const handleChangeMaxPrice = (e: any) => {
    //     console.log(e.target.value)
    //     setMaxPrice(e.target.value);
    // }

    let searchedBook = searchArray.map((book: any, index: any) => {
        return (
            <Link to={`/${book._id}`}>
                <OneMovie movie={book}></OneMovie>
            </Link>
        )
    })
    return (
        <>

            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light">
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        {/* <ul className="navbar-nav mr-auto">
                            &nbsp;
                        <select onChange={handleSelect} className="select">
                                <option>Select</option>
                                <option>Title</option>
                                <option>imdbID</option>
                                <option>price</option>
                                <option>rating</option>
                            </select>
                        </ul>&nbsp;&nbsp; */}
                        {/* {price ? <>
                            <label>min price</label>
                            <input className="form-inline my-2 my-lg-0" type="search" name="search" onChange={handleChangeMinPrice} /> &nbsp;
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item active">
                                </li>
                            </ul>
                            <label>max price</label>
                            <input className="form-inline my-2 my-lg-0" type="search" name="search" onChange={handleChangeMaxPrice} /> &nbsp;
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item active">

                                </li>
                            </ul>
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item active">
                                    <button className="btn btn-outline-success my-2 my-sm-0" type="submit" onClick={handleSearchButton} >Search</button>
                                </li>
                            </ul>
                        </> : */}
                        <>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input className="form-inline my-2 my-lg-0" type="search" name="search" onChange={handleSearch} /> &nbsp;
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item active">
                                    <button className="btn btn-outline-success my-2 my-sm-0" type="submit" onClick={handleSearchButton} >Search</button>
                                </li>
                            </ul>

                        </>

                    </div>
                </nav>
                {searchedBook}<br /><br /><br />
            </div>
        </>
    )
}

export default Searching