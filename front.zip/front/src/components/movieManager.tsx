import axios from 'axios';
import { movie } from './movie'
import React, { Component } from 'react'

export class movieManager {
    getAllMovies(dispatch: any) {
        axios.get("http://localhost:9000/api/movies")
            .then((res) => {
                dispatch({ type: "LIST", books: res.data })
            })
            .catch((err) => {
                console.log(err.message)
            })
    }
   
    loggingIn = async (username: string, password: string) => {
        let data = await fetch(`http://localhost:9000/api/users/login`, {
            method: "POST",
            body: JSON.stringify({ username: username, password: password }),
            headers: { "Content-Type": "application/json" }
        }
        )
        return data
    }
    loggingInWIthOtp = async (username: string, password: string, otp: string) => {
        let data = await fetch(`http://localhost:9000/api/users/otpverifying`, {
            method: "POST",
            body: JSON.stringify({ username: username, password: password, otp: otp }),
            headers: { "Content-Type": "application/json" }
        })
        return data
    }
    
    render() {
        return (
            <div>

            </div>
        )
    }
}

export default movieManager
