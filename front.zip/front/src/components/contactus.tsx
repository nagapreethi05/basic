import React from 'react';

const ContactUs=()=>{
    
    return(<>
        <div className="contactUs" style={{"textAlign":"center"}}><h3>Contact us</h3>
        <p>Phone no:XXXXXXXXXX<br/><br/>
        email:bookmanagement@gmail.com</p></div>
        
</>

    )
}
export default ContactUs
