import React, { useReducer } from 'react'
import { movie } from "./movie"
import { user } from "./user"
import reducer from '../reducer'
interface Iusercontext {
    moviesArray: {
        books: [],
        users: [],
        user: boolean,
        selectedmovie: [],
        search: []
    }
    dispatch: React.Dispatch<any>
}
const initalState = {
    books: [],
    user: false,
    selectedmovie: [],
    search: []
}

const UserContext = React.createContext<Iusercontext>({} as Iusercontext);
const UserProvider = (props: any) => {
    const [moviesArray, dispatch] = useReducer(reducer, initalState, () => {
        return initalState;
    })
    return (
        <UserContext.Provider value={{ moviesArray, dispatch }} >
            {props.children}
        </UserContext.Provider>
    )
}
const UserConsumer = UserContext.Consumer;
export { UserProvider, UserConsumer }
export default UserContext