"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var Movies_controller_1 = require("../Controller/Movies-controller");
var moviesRouter = express_1.default.Router();
moviesRouter.get('/', Movies_controller_1.getAllMovies);
moviesRouter.get("/:id", Movies_controller_1.getById);
moviesRouter.get("/search/:Title", Movies_controller_1.getByTitle);
exports.default = moviesRouter;
