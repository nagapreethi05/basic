import react, { useContext } from 'react'
import { useParams, useHistory } from 'react-router'
import { Card, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css'
import UserContext from './UserContext';
import Star from './Star';
import movieManager from './movieManager'

const Details = (props: any) => {
    const { _id }: any = useParams();
    const history = useHistory();
    const bmObj = new movieManager;
    const { moviesArray, dispatch } = useContext(UserContext);

    let detailmovie = moviesArray.books.map((movie: any, index) => {
        if (movie._id == _id) {

            return (
                <div style={{ fontFamily: "Times New Roman", padding: "20px" }}>
                    <h1 style={{ textAlign: "center" }}><strong>{movie.Title}</strong></h1><hr /><br />
                    <div className="container">
                        <div className="row">
                            <div className="col-3">
                                <img className="card-img-top  mh-70 w-1 shadow p-1 mb-3 bg-white rounded" style={{ "float": "left" }} src={movie.Poster}></img>
                            </div>

                            <div className="col-2">
                                <Card className="box1 h-199 w-30 align-right shadow p-3 mb-5 bg-white rounded ">
                                    <div className="card" style={{ width: "30rem", height: "50rem" }}>
                                        <ul className="list-group list-group-flush">
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "1rem 1rem" }}><h4><strong>Title:</strong>{movie.Title}</h4></li>
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Year:</strong>{movie.Year}</h4></li>
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Director:</strong>{movie.Director}</h4></li>
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Rating:</strong>{movie.Rated}</h4></li>
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>imdbID:</strong>{movie.imdbID}</h4></li>
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Released:</strong>{movie.Released}</h4></li>
                                            <li className="list-group-item" style={{ width: "30rem", height: "3rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Genre:</strong>{movie.Genre}</h4></li>
                                        </ul>
                                    </div>
                                </Card>
                            </div>
                        </div>
                    </div>
                </div>
            )
        }
    })
    return (
        <div>{detailmovie}</div>
    )
}
export default Details