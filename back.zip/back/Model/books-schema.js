"use strict";
var mongoosee = require('mongoose');
var bookSchema = new mongoosee.Schema({
    Title: {
        type: String,
    },
    year: {
        type: String,
    },
    imdbID: {
        type: String
    },
    Poster: {
        type: String
    },
}, { collection: "newmovie" });
module.exports = mongoosee.model('book', bookSchema);
