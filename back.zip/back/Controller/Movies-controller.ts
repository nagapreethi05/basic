import express from 'express';
import Movies from '../Model/Movies-schema';
import { authenticate } from './users-controller'
import fetch from 'node-fetch'
export const moviesRouter = express.Router()

export const getMovies=async(params:any)=>{
    try{
        let res=await fetch(`https://www.omdbapi.com/?apikey=3e8e54b4&${params}`)
        let data=await res.json()
        console.log(data)
        return data;
        
    }
    catch(err){
        console.log(err)
    }
}
export const getAllMovies=async (req: any, res: any) => {
    let Title = req.query.Title;
    let Year = req.query.Year;
    
    let imdbID = req.query.imdbID;
    let type = req.query.type;
    
    console.log(Title)
    if (Title) {
        try {
            const movies = await Movies.find({ Title: {$regex:new RegExp(Title) ,$options:"i"}});
            if (movies) {
                return res.status(200).json(movies);
            } else {
                return res.status(404).json("title not found");
            }
        } catch (err) {
            res.send('Error ' + err)
        }
    }
    
    else if (imdbID) {
        try {
            const movies = await Movies.find({ imdbID: {$regex:new RegExp(imdbID) ,$options:"i"}});
            if (movies) {
                return res.status(200).json(movies);
            } else {
                return res.status(404).json("imdbId not found");
            }
        } catch (err) {
            res.send('Error ' + err)
        }
    }

    else {
        try {
            const movies = await Movies.find();
            res.json(movies);
        }
        catch (err) {
            res.send("Error " + err);
        }
    }
};
//search by id
export const getById= async (req: any, res: any) => {
    try {
        const movies: any = await Movies.find({imdbID:req.params.id});
        if (movies.length!=0) {
            res.status(200).json(movies);
            console.log("if")
        }
        else {

            let moviesall=await getMovies(`i=${req.params.id}`)
            const newMovie=new Movies({...moviesall})
            const m1=await newMovie.save();
            res.status(200).json(m1);
        }
    } catch (err) {
        res.send("error" + err.message);
    }
};
//search by title
export const getByTitle= async (req: any, res: any) => {
    try {
        const movies: any = await Movies.find({Title: {$regex:new RegExp(req.params.Title) ,$options:"i"}});
        console.log(movies)
        if (movies.length!=0) {
            res.status(200).json(movies);
            console.log("title if")
        }
        else {
            let moviesall=await getMovies(`t=${req.params.Title}`)
            console.log("title else")
            const newMovie=new Movies({...moviesall})
            const m1=await newMovie.save();
            
            res.status(200).json(m1);
        }
    } catch (err) {
        res.send("error" + err.message);
    }
};
 