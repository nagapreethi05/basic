import react from 'react';
import { movie } from './movie';
import Star from './Star'
import { Navbar, Nav, Button, Form, Col, Card, FormControl } from 'react-bootstrap';

interface Iprops {
    movie: movie;
}
const OneMovie = (props: Iprops) => {
    return (
        <>
            <Card  className="box h-199 w-12 shadow p-3 mb-5 bg-white rounded ">
                <Card.Img className="box-image" src={props.movie.Poster} title={props.movie.Title} />
                <Card.Body className="box-body ">
                    <Card.Text className="h-100 w-10" >
                        <h4 style={{"color":"black"}}><strong >Title:</strong>{props.movie.Title}</h4>
                        <h4><strong>IMDBID:</strong>{props.movie.imdbID}</h4>
                                            
                    </Card.Text></Card.Body>
            </Card>
           
        </>
    )
}
export default OneMovie;