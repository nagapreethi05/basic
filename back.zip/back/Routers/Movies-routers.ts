import express from "express";
import {getAllMovies,getById,getByTitle} from '../Controller/Movies-controller'
import {authenticate, userlogin,otpverify,getuser,registration} from '../Controller/users-controller';
const moviesRouter=express.Router();

moviesRouter.get('/',getAllMovies);
moviesRouter.get("/:id",getById);
moviesRouter.get("/search/:Title",getByTitle);
export default moviesRouter;