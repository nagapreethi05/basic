"use strict";
var mongoosee = require('mongoose');
var movieSchema = new mongoosee.Schema({
    Title: {
        type: String,
    },
    Year: {
        type: String,
    },
    imdbID: {
        type: String
    },
    Poster: {
        type: String
    },
    Rated: {
        type: String
    },
    Released: {
        type: String
    },
    Genre: {
        type: String
    },
    Director: {
        type: String
    },
}, { collection: "newmovie" });
module.exports = mongoosee.model('movie', movieSchema);
