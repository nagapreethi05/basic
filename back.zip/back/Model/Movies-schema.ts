const mongoosee = require('mongoose')
const movieSchema = new mongoosee.Schema({
    Title: {
        type: String,
    },
    Year: {
        type: String,
    },
    imdbID: {
        type: String
    },

    Poster: {
        type: String
    }
    ,
    Rated: {
        type: String
    },
    Released: {
        type: String
    },
    Genre: {
        type: String
    },

    Director: {
        type: String
    },
},
    { collection: "newmovie" }
)
export = mongoosee.model('movie', movieSchema)
